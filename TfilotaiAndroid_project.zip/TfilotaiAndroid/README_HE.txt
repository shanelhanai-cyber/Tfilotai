תפילותיי – פרויקט Android

הקובץ app/src/main/assets/index.html הוא דף ה-HTML המלא שסופק, והוא נארז בתוך האפליקציה. אין צורך להעלות את הדף לאתר או לאחסן אותו ברשת.

בניית APK:
1. מעלים את כל תוכן התיקייה הזו (כולל התיקייה .github) למאגר GitHub חדש בשם Tfilotai.
2. פותחים במאגר את Actions ומאשרים הפעלת Workflows אם GitHub מבקש.
3. בוחרים Build Android APK ולוחצים Run workflow.
4. בסיום נכנסים להרצה שהסתיימה ומורידים את Artifact בשם Tfilotai-APK. בתוך ZIP ההורדה נמצא app-debug.apk.

זהו APK לבדיקה והתקנה ידנית באנדרואיד. לפרסום בחנות Google Play נדרשים בהמשך חתימה ושחרור AAB.
